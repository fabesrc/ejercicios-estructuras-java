public class Main {
    public static void main(String[] args) {

        Carrito<Producto> carrito = new Carrito<>();

        // Crear algunos productos
        Producto p1 = new Producto("Teclado Mecánico", 85.50);
        Producto p2 = new Producto("Monitor 4K", 320.00);
        Producto p3 = new Producto("Mouse Gamer", 45.00);

        // Agregar productos
        carrito.agregar(p1);
        carrito.agregar(p2);
        carrito.agregar(p3);

        // Probar el producto de mayor precio
        Producto masCaro = carrito.precioMayor();
        System.out.println("Producto de mayor precio: " + masCaro);

        // Probar el método para calcular el total
        System.out.println("Precio total de la compra: $" + carrito.calcularPrecioTotal());
    }
}