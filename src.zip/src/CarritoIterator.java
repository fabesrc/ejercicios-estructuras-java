import java.util.Iterator;

public class CarritoIterator implements Iterator<T> {
    int indice = 0;
    List<T> lista;

    public CarritoIterator(List<T> lista) {
        this.lista = lista;
    }


    @Override
    public boolean hasNext() {
        return false;
    }

    @Override
    public T next() {
        return null;
    }
}
